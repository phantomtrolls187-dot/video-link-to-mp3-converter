require("dotenv").config();

const express = require("express");
const https = require("node:https");
const dns = require("node:dns").promises;
const net = require("node:net");
const path = require("node:path");
const os = require("node:os");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const { Transform } = require("node:stream");
const { pipeline } = require("node:stream/promises");
const { spawn } = require("node:child_process");
const ipaddr = require("ipaddr.js");
const ffmpegPath = require("ffmpeg-static");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MAX_VIDEO_BYTES = Number(process.env.MAX_VIDEO_MB || 250) * 1024 * 1024;
const MAX_CONVERSION_SECONDS = Number(process.env.MAX_CONVERSION_SECONDS || 180);
const ALLOWED_HOSTS = new Set(
  (process.env.ALLOWED_VIDEO_HOSTS || "")
    .split(",")
    .map((host) => host.trim().toLowerCase())
    .filter(Boolean)
);

app.disable("x-powered-by");
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public"), {
  extensions: ["html"]
}));

// Small in-memory rate limit: 5 conversion requests per IP per 10 minutes.
// For a public deployment, use a shared store such as Redis.
const attempts = new Map();
function rateLimit(req, res, next) {
  const key = req.ip;
  const now = Date.now();
  const windowMs = 10 * 60 * 1000;
  const record = attempts.get(key) || { count: 0, resetAt: now + windowMs };

  if (now > record.resetAt) {
    record.count = 0;
    record.resetAt = now + windowMs;
  }

  record.count += 1;
  attempts.set(key, record);

  if (record.count > 5) {
    return res.status(429).json({
      error: "Too many requests. Please wait a few minutes and try again."
    });
  }
  next();
}

function isPublicAddress(address) {
  try {
    const parsed = ipaddr.process(address);
    return parsed.range() === "unicast";
  } catch {
    return false;
  }
}

async function validateSource(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error("Enter a valid direct video-file URL.");
  }

  if (url.protocol !== "https:") {
    throw new Error("Only HTTPS video URLs are accepted.");
  }
  if (url.username || url.password) {
    throw new Error("URLs containing usernames or passwords are not accepted.");
  }
  if (url.port && url.port !== "443") {
    throw new Error("Only the standard HTTPS port (443) is accepted.");
  }

  const hostname = url.hostname.toLowerCase();
  if (net.isIP(hostname) || !ALLOWED_HOSTS.has(hostname)) {
    throw new Error("This video host is not on the server's approved-host list.");
  }

  const addresses = await dns.lookup(hostname, { all: true, verbatim: true });
  if (!addresses.length || addresses.some((entry) => !isPublicAddress(entry.address))) {
    throw new Error("The video host did not resolve to an approved public address.");
  }

  // Pin the request to a checked address to reduce DNS-rebinding/SSRF risk.
  return { url, address: addresses[0] };
}

function downloadHttpsFile(url, address, destination) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let received = 0;

    const finishError = (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    };

    const request = https.request({
      protocol: "https:",
      hostname: url.hostname,
      port: 443,
      method: "GET",
      path: `${url.pathname}${url.search}`,
      servername: url.hostname,
      rejectUnauthorized: true,
      lookup: (_hostname, _options, callback) => {
        callback(null, address.address, address.family);
      },
      headers: {
        "User-Agent": "AuthorizedMediaConverter/1.0",
        "Accept": "video/*,application/octet-stream;q=0.9"
      }
    }, async (response) => {
      if (response.statusCode !== 200) {
        response.resume();
        return finishError(new Error(
          `The source server returned HTTP ${response.statusCode}. Redirects are not followed.`
        ));
      }

      const contentType = String(response.headers["content-type"] || "").toLowerCase();
      if (!(contentType.startsWith("video/") ||
            contentType.startsWith("application/octet-stream"))) {
        response.resume();
        return finishError(new Error(
          "The approved URL did not return a video or binary media file."
        ));
      }

      const declaredLength = Number(response.headers["content-length"] || 0);
      if (declaredLength > MAX_VIDEO_BYTES) {
        response.resume();
        return finishError(new Error(
          `The video is too large. Maximum size is ${Math.round(MAX_VIDEO_BYTES / 1024 / 1024)} MB.`
        ));
      }

      const limiter = new Transform({
        transform(chunk, encoding, callback) {
          received += chunk.length;
          if (received > MAX_VIDEO_BYTES) {
            callback(new Error(
              `The video is too large. Maximum size is ${Math.round(MAX_VIDEO_BYTES / 1024 / 1024)} MB.`
            ));
          } else {
            callback(null, chunk);
          }
        }
      });

      try {
        await pipeline(response, limiter, fs.createWriteStream(destination, { flags: "wx" }));
        if (settled) return;
        settled = true;
        resolve();
      } catch (error) {
        finishError(error);
      }
    });

    request.setTimeout(30_000, () => {
      request.destroy(new Error("The video host took too long to respond."));
    });
    request.on("error", finishError);
    request.end();
  });
}

function convertToMp3(inputPath, outputPath) {
  return new Promise((resolve, reject) => {
    const args = [
      "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
      "-i", inputPath,
      "-map", "0:a:0",
      "-vn",
      "-codec:a", "libmp3lame",
      "-q:a", "2",
      "-f", "mp3",
      outputPath
    ];

    const child = spawn(ffmpegPath, args, { stdio: ["ignore", "ignore", "pipe"] });
    let errorText = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
    }, MAX_CONVERSION_SECONDS * 1000);

    child.stderr.on("data", (chunk) => {
      errorText += chunk.toString();
      if (errorText.length > 6000) errorText = errorText.slice(-6000);
    });

    child.on("error", (error) => {
      clearTimeout(timer);
      reject(error);
    });

    child.on("close", (code) => {
      clearTimeout(timer);
      if (code === 0) return resolve();
      if (code === null) {
        return reject(new Error("Conversion timed out. Try a shorter video."));
      }
      if (/does not contain any stream|matches no streams|Stream map/i.test(errorText)) {
        return reject(new Error("This video does not appear to contain an audio track."));
      }
      reject(new Error("Could not convert this video. Check that the URL points directly to a supported video file."));
    });
  });
}

app.post("/api/convert", rateLimit, async (req, res) => {
  const rawUrl = typeof req.body?.url === "string" ? req.body.url.trim() : "";
  if (!rawUrl) {
    return res.status(400).json({ error: "Paste a direct video-file URL first." });
  }

  let workDir;
  try {
    if (!ALLOWED_HOSTS.size) {
      return res.status(503).json({
        error: "The server owner must configure ALLOWED_VIDEO_HOSTS in the .env file first."
      });
    }

    const { url, address } = await validateSource(rawUrl);
    workDir = await fsp.mkdtemp(path.join(os.tmpdir(), "video-mp3-"));
    const inputPath = path.join(workDir, "source-video");
    const outputPath = path.join(workDir, "converted-audio.mp3");

    await downloadHttpsFile(url, address, inputPath);
    await convertToMp3(inputPath, outputPath);

    const safeBase = path.basename(url.pathname || "audio")
      .replace(/\.[^.]+$/, "")
      .replace(/[^a-z0-9_-]/gi, "_")
      .slice(0, 60) || "converted-audio";

    res.setHeader("Content-Type", "audio/mpeg");
    res.setHeader("Content-Disposition", `attachment; filename="${safeBase}.mp3"`);
    res.setHeader("Cache-Control", "no-store");

    await pipeline(fs.createReadStream(outputPath), res);
  } catch (error) {
    if (!res.headersSent) {
      res.status(400).json({ error: error.message || "Conversion failed." });
    } else {
      res.destroy(error);
    }
  } finally {
    if (workDir) {
      await fsp.rm(workDir, { recursive: true, force: true }).catch(() => {});
    }
  }
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

app.listen(PORT, () => {
  console.log(`VIDEO LINK TO MP3 CONVERTER running at http://localhost:${PORT}`);
  if (!ALLOWED_HOSTS.size) {
    console.warn("Set ALLOWED_VIDEO_HOSTS in .env before using URL conversion.");
  }
});
