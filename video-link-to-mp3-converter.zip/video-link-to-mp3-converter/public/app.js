const urlInput = document.getElementById("videoUrl");
const convertBtn = document.getElementById("convertBtn");
const buttonText = document.getElementById("buttonText");
const statusBox = document.getElementById("status");
const statusText = document.getElementById("statusText");
const progressWrap = document.getElementById("progressWrap");
const clearBtn = document.getElementById("clearBtn");

function setStatus(message, type = "") {
  statusText.textContent = message;
  statusBox.className = `status ${type}`.trim();
}

clearBtn.addEventListener("click", () => {
  urlInput.value = "";
  urlInput.focus();
  setStatus("Ready when you are. Paste a direct video URL above.");
});

convertBtn.addEventListener("click", async () => {
  const url = urlInput.value.trim();

  if (!url) {
    setStatus("Please paste a direct video-file URL first.", "error");
    urlInput.focus();
    return;
  }

  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:") {
      throw new Error("Please use a secure HTTPS video URL.");
    }
  } catch (error) {
    setStatus(error.message || "Please enter a valid URL.", "error");
    return;
  }

  convertBtn.disabled = true;
  buttonText.textContent = "CONVERTING…";
  progressWrap.hidden = false;
  setStatus("Connecting to the approved video host. This may take a moment.");

  try {
    const response = await fetch("/api/convert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });

    const contentType = response.headers.get("content-type") || "";
    if (!response.ok || !contentType.includes("audio/mpeg")) {
      const data = contentType.includes("application/json")
        ? await response.json()
        : { error: "The conversion could not be completed." };
      throw new Error(data.error || "Conversion failed.");
    }

    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const disposition = response.headers.get("content-disposition") || "";
    const match = disposition.match(/filename="([^"]+)"/i);
    const filename = match ? match[1] : "converted-audio.mp3";

    const link = document.createElement("a");
    link.href = objectUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();

    setStatus("Your MP3 is ready. The download has started.", "success");
    setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
  } catch (error) {
    setStatus(error.message || "Something went wrong. Please try again.", "error");
  } finally {
    convertBtn.disabled = false;
    buttonText.textContent = "CONVERT TO MP3";
    progressWrap.hidden = true;
  }
});
