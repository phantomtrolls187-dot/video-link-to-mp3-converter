# VIDEO LINK TO MP3 CONVERTER

A Node.js + Express application that converts **direct HTTPS video-file URLs** into MP3. It is intentionally limited to exact hostnames configured by the site owner. It is not a YouTube/social-media downloader and does not bypass access controls, DRM, logins, or platform restrictions.

## Requirements

- Node.js 20 or newer
- npm
- An HTTPS host that you own or are authorized to process, serving direct video files
- Internet access for npm install

`ffmpeg-static` supplies the FFmpeg executable through npm.

## Setup

1. Extract this project folder.
2. Open a terminal in the project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env`.
5. Edit `.env` and set the exact approved hostname(s):

   ```env
   ALLOWED_VIDEO_HOSTS=media.yourdomain.com,cdn.yourdomain.com
   PORT=3000
   MAX_VIDEO_MB=250
   MAX_CONVERSION_SECONDS=180
   ```

   Do not add `https://`, paths, wildcards, or hostnames you do not control or have permission to use.

6. Start the app:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000`.

## What URL works?

Use a direct URL to a video file hosted on one of the exact approved domains, for example:

`https://media.yourdomain.com/my-video.mp4`

The URL must:
- use HTTPS on the standard port 443;
- resolve to public IP addresses;
- return the video file directly with HTTP 200 (redirects are not followed);
- return a `video/*` or `application/octet-stream` content type;
- contain an audio track for MP3 extraction.

A normal webpage URL, a YouTube watch page, or a social-media share link is not a direct video-file URL and will not work. Only process content you own or are authorized to use.

## Limits and security notes

- Maximum input size defaults to 250 MB.
- Conversion time defaults to 180 seconds.
- A basic in-memory limit allows 5 conversions per IP per 10 minutes.
- The server checks the hostname against an exact allowlist, checks DNS results for public IPs, pins the HTTPS request to a checked address, rejects redirects, and limits download size.
- Temporary files are removed after the response finishes.
- For a public production deployment, add authentication, a reverse-proxy request/body timeout, persistent rate limiting (for example Redis), monitoring, and a job queue. Keep the allowlist narrow.
- Do not expose the service as an unrestricted public URL-fetching proxy.

## Project structure

```text
video-link-to-mp3-converter/
├── public/
│   ├── app.js
│   ├── index.html
│   └── styles.css
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```
